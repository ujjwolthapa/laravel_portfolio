
<?php $__env->startSection('content'); ?>
    <main>
        <div class="container-fluid">
            <h1 class="mt-4">List of Abouts</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item active">List of Abouts</li>
            </ol>
            <table class="table table-bordered">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Title 1</th>
                    <th scope="col">Title 2</th>
                    <th scope="col">Image</th>
                    <th scope="col">Description</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
                    <?php if(count($abouts) > 0): ?>
                        <?php $__currentLoopData = $abouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $about): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($about->id); ?></th>
                                <td><?php echo e($about->title1); ?></td>
                                <td><?php echo e($about->title2); ?></td>
                                <td><?php echo e(Str::limit(strip_tags($about->description),40)); ?></td>
                                <td>
                                    <img style="height: 10vh" src="<?php echo e(url($about->image)); ?>" alt="image">
                                </td>
                                <td>
                                    <div class="row">
                                        <div>
                                            <a href="<?php echo e(route('admin.abouts.edit', $about->id)); ?>" class="btn btn-primary m-2">Edit</a>
                                        </div>
                                        <div>
                                            <form action="<?php echo e(route('admin.abouts.destroy', $about->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <input type="submit" name="submit" value="Delete" class="btn btn-danger m-2">
                                            </form>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    <?php endif; ?>
                  
                </tbody>
              </table>
    </main>
<?php $__env->stopSection(); ?>
                
                
<?php echo $__env->make('layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravelapp\resources\views/pages/abouts/list.blade.php ENDPATH**/ ?>