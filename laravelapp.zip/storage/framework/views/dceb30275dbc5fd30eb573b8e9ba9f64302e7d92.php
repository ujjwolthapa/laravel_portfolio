<?php $__env->startSection('content'); ?>
    <main>
        <div class="container-fluid">
            <h1 class="mt-4">Dashboard</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item active">Dashboard</li>
            </ol>
        
        
    </main>
    
<?php $__env->stopSection(); ?>                


<?php echo $__env->make('layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravelapp\resources\views/pages/dashboard.blade.php ENDPATH**/ ?>