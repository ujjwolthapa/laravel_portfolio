
<?php $__env->startSection('content'); ?>
    <main>
        <div class="container-fluid">
            <h1 class="mt-4">List of Services</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item active">List of Services</li>
            </ol>
            <table class="table table-bordered">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Title</th>
                    <th scope="col">Sub Title</th>
                    <th scope="col">Big Image</th>
                    <th scope="col">Small Image</th>
                    <th scope="col">Description</th>
                    <th scope="col">Client</th>
                    <th scope="col">Category</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
                    <?php if(count($portfolios) > 0): ?>
                        <?php $__currentLoopData = $portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $portfolio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($portfolio->id); ?></th>
                                <td><?php echo e($portfolio->title); ?></td>
                                <td><?php echo e($portfolio->sub_title); ?></td>
                                <td><?php echo e(Str::limit(strip_tags($portfolio->description),40)); ?></td>
                                <td>
                                    <img style="height: 10vh" src="<?php echo e(url($portfolio->big_image)); ?>" alt="big_image">
                                </td>
                                <td>
                                    <img style="height: 10vh" src="<?php echo e(url($portfolio->small_image)); ?>" alt="big_image">
                                </td>
                                <td><?php echo e($portfolio->client); ?></td>
                                <td><?php echo e($portfolio->category); ?></td>
                                <td>
                                    <div class="row">
                                        <div>
                                            <a href="<?php echo e(route('admin.portfolios.edit', $portfolio->id)); ?>" class="btn btn-primary m-2">Edit</a>
                                        </div>
                                        <div>
                                            <form action="<?php echo e(route('admin.portfolios.destroy', $portfolio->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <input type="submit" name="submit" value="Delete" class="btn btn-danger m-2">
                                            </form>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    <?php endif; ?>
                  
                </tbody>
              </table>
    </main>
<?php $__env->stopSection(); ?>
                
                
<?php echo $__env->make('layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravelapp\resources\views/pages/portfolios/list.blade.php ENDPATH**/ ?>